# Prospection web (Cloudflare Worker + D1)

Une page sobre, protégée par mot de passe, qui :

- cherche des établissements locaux (ex. « coiffeur La Baule ») via l'API officielle Google Places ;
- repère ceux **sans site** (score 100), avec un site **injoignable ou réseau social** (90), ou avec un **site ancien** (HTTPS absent, pas adapté au mobile, copyright ancien, technologies obsolètes, PageSpeed faible) ;
- classe les prospects par score, permet de suivre le contact (à contacter, contacté, relancé, refus, client) et d'exporter en CSV.

## Ce dont tu as besoin

1. Un compte **Cloudflare** (gratuit suffit) : https://dash.cloudflare.com/sign-up
2. **Node.js 18 ou plus** sur ton ordinateur : https://nodejs.org
3. Une **clé API Google** :
   - Crée un projet sur https://console.cloud.google.com et active la facturation.
   - Active deux API : **Places API (New)** et **PageSpeed Insights API**.
   - Crée une clé dans « Identifiants » et restreins-la à ces deux API.
   - Dans « Facturation > Budgets et alertes », fixe un budget avec alerte. Les champs téléphone et site web de Places sont facturés au tarif le plus élevé : vérifie la grille tarifaire actuelle avant de lancer de grosses recherches.

## Déploiement sur Cloudflare, pas à pas

Dans un terminal, depuis le dossier du projet :

**1. Installer les outils**

```bash
npm install
npx wrangler login
```

Le navigateur s'ouvre : autorise l'accès à ton compte Cloudflare.

**2. Créer la base de données D1**

```bash
npx wrangler d1 create prospection
```

La commande affiche un `database_id`. Copie-le dans `wrangler.toml`, à la place de `REMPLACE_PAR_TON_ID`.

**3. Créer la table**

```bash
npx wrangler d1 execute prospection --remote --file=schema.sql
```

**4. Enregistrer les deux secrets**

```bash
npx wrangler secret put GOOGLE_API_KEY
npx wrangler secret put APP_PASSWORD
```

Colle la valeur quand elle est demandée. Pour `APP_PASSWORD`, choisis un mot de passe solide en caractères ASCII (sans accents). L'identifiant de connexion sera `admin`.

**5. Déployer**

```bash
npx wrangler deploy
```

L'adresse s'affiche, de la forme `https://prospection.TON-SOUS-DOMAINE.workers.dev`. Ouvre-la, entre `admin` et ton mot de passe : la page est en ligne.

## Utilisation

1. Saisis un **secteur** et une **ville**, puis « Rechercher ». Les établissements sans site apparaissent tout de suite avec un score de 100.
2. Clique sur « Analyser les sites » pour évaluer les autres. L'analyse tourne aussi toute seule toutes les 30 minutes.
3. Filtre par score, statut ou texte, change le statut et ajoute des notes directement dans le tableau.
4. « Exporter en CSV » respecte les filtres en cours (séparateur point-virgule, ouverture directe dans Excel).

## Tester en local (facultatif)

```bash
cp .dev.vars.example .dev.vars     # puis renseigne tes valeurs
npm run db:local
npm run dev                        # http://localhost:8787
```

## Options

- **Nom de domaine perso** : tableau de bord Cloudflare > Workers & Pages > prospection > Settings > Domains & Routes > Add.
- **Protection renforcée** : Cloudflare Zero Trust > Access permet de n'autoriser que ton adresse e-mail, en plus du mot de passe.
- **Désactiver l'analyse automatique** : supprime le bloc `[triggers]` de `wrangler.toml` puis redéploie.
- **Désactiver PageSpeed** (plus rapide, moins précis) : mets `USE_PAGESPEED = "false"` dans `wrangler.toml`.
- **Modifier les pondérations du score** : fonction `analyseSite` dans `src/index.js`.

## Limites à connaître

- Plan gratuit Workers : 50 sous-requêtes par exécution, d'où des analyses par petits lots (le bouton enchaîne les lots tout seul).
- Une recherche renvoie au maximum 60 résultats par couple secteur + ville.
- Le dernier snapshot archive.org est donné à titre d'information, il n'entre pas dans le score.
- L'analyse ne consulte pas le fichier robots.txt des sites : elle charge uniquement la page d'accueil, une fois par analyse.
- Certains sites bloquent les robots : ils sont signalés « Contenu non analysable » et ne reçoivent que les points HTTPS et PageSpeed.

## Cadre légal (France)

- Données Google Places uniquement via l'API officielle, jamais par scraping de Google Maps.
- Ne stocke que des établissements professionnels.
- Prospection B2B par e-mail : adresse professionnelle, message en rapport avec l'activité, moyen de se désinscrire (règles de la CNIL). Pour les petits commerces, téléphone ou visite restent les canaux les plus simples.

## Dépannage

| Symptôme | Cause probable |
|---|---|
| 503 « APP_PASSWORD n'est pas configuré » | Étape 4 non faite, puis redéployer |
| Erreur « Google Places : 403 » | API non activée ou clé restreinte à d'autres API |
| Erreur D1 « no such table » | Étape 3 oubliée (ou `--remote` manquant) |
| Erreur D1 « binding » | `database_id` non renseigné dans `wrangler.toml` |
| Mot de passe refusé | Accents ou caractères non ASCII dans `APP_PASSWORD` |
