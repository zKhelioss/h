// Prospection web : Cloudflare Worker + base D1.
// Trouve des établissements locaux (API officielle Google Places), repère ceux
// sans site ou avec un site obsolète, et suit le statut de contact.

const STATUTS = ["à contacter", "contacté", "relancé", "refus", "client"];

// Domaines qui ne comptent pas comme un site propre.
const SANS_SITE_PROPRE = [
  "facebook.com", "instagram.com", "linktr.ee", "tiktok.com", "linkedin.com",
  "twitter.com", "x.com", "pagesjaunes.fr", "doctolib.fr", "tripadvisor.fr",
  "tripadvisor.com", "thefork.fr", "ubereats.com",
];

const UA = "Mozilla/5.0 (compatible; ProspectionBot/1.0)";

export default {
  async fetch(request, env) {
    const refus = verifierAcces(request, env);
    if (refus) return refus;

    const url = new URL(request.url);
    const { pathname } = url;
    const m = request.method;

    try {
      if (m === "GET" && pathname === "/") {
        return new Response(PAGE, {
          headers: {
            "Content-Type": "text/html; charset=utf-8",
            "Cache-Control": "no-store",
            "X-Frame-Options": "DENY",
            "X-Content-Type-Options": "nosniff",
          },
        });
      }
      if (m === "GET" && pathname === "/api/prospects") return json({ prospects: await lister(url, env) });
      if (m === "GET" && pathname === "/api/export.csv") return await exporterCsv(url, env);
      if (m === "POST" && pathname === "/api/search") return json(await rechercher(await lireJson(request), env));
      if (m === "POST" && pathname === "/api/analyze") return json(await analyser(await lireJson(request), env));
      if (m === "POST" && pathname === "/api/status") return json(await majStatut(await lireJson(request), env));
      return new Response("Introuvable", { status: 404 });
    } catch (e) {
      return json({ error: e.message || "Erreur" }, e.status || 500);
    }
  },

  // Tâche planifiée : analyse automatiquement les sites en attente.
  async scheduled(_event, env, ctx) {
    ctx.waitUntil(analyser({ limit: 8 }, env));
  },
};

/* ---------- Utilitaires ---------- */

function erreur(message, status = 400) {
  const e = new Error(message);
  e.status = status;
  return e;
}

function json(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store" },
  });
}

async function lireJson(request) {
  // Exiger application/json force un contrôle préalable du navigateur (protège du CSRF).
  if (!(request.headers.get("Content-Type") || "").includes("application/json")) {
    throw erreur("Content-Type application/json requis", 415);
  }
  try {
    return await request.json();
  } catch {
    throw erreur("Corps JSON invalide");
  }
}

function egal(a, b) {
  if (a.length !== b.length) return false;
  let diff = 0;
  for (let i = 0; i < a.length; i++) diff |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return diff === 0;
}

// Accès protégé par mot de passe (identifiant : admin).
function verifierAcces(request, env) {
  if (!env.APP_PASSWORD) {
    return new Response("APP_PASSWORD n'est pas configuré (wrangler secret put APP_PASSWORD).", { status: 503 });
  }
  const recu = request.headers.get("Authorization") || "";
  const attendu = "Basic " + btoa("admin:" + env.APP_PASSWORD);
  if (egal(recu, attendu)) return null;
  return new Response("Authentification requise", {
    status: 401,
    headers: { "WWW-Authenticate": 'Basic realm="Prospection", charset="UTF-8"' },
  });
}

function maintenantSql() {
  return new Date().toISOString().slice(0, 19).replace("T", " ");
}

/* ---------- Recherche d'établissements (Google Places) ---------- */

const UPSERT = `
INSERT INTO prospects (place_id, nom, secteur, ville, adresse, telephone, note, avis, site, score, raisons, analyse_le)
VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
ON CONFLICT(place_id) DO UPDATE SET
  nom = excluded.nom,
  adresse = excluded.adresse,
  telephone = excluded.telephone,
  note = excluded.note,
  avis = excluded.avis,
  score = CASE WHEN excluded.site IS NULL THEN 100
               WHEN prospects.site IS excluded.site THEN prospects.score ELSE NULL END,
  raisons = CASE WHEN excluded.site IS NULL THEN 'Aucun site web'
                 WHEN prospects.site IS excluded.site THEN prospects.raisons ELSE '' END,
  analyse_le = CASE WHEN excluded.site IS NULL THEN excluded.analyse_le
                    WHEN prospects.site IS excluded.site THEN prospects.analyse_le ELSE NULL END,
  site = excluded.site`;

async function rechercher(corps, env) {
  const secteur = String(corps.secteur || "").trim();
  const ville = String(corps.ville || "").trim();
  if (!secteur || !ville) throw erreur("Secteur et ville requis");
  if (!env.GOOGLE_API_KEY) throw erreur("GOOGLE_API_KEY n'est pas configurée", 500);

  const limite = Math.min(Math.max(parseInt(corps.max, 10) || 20, 1), 60);
  let jeton;
  let vus = 0;
  let sansSite = 0;

  while (vus < limite) {
    const requete = {
      textQuery: secteur + " " + ville,
      languageCode: "fr",
      regionCode: "FR",
      pageSize: Math.min(20, limite - vus),
    };
    if (jeton) requete.pageToken = jeton;

    const r = await fetch("https://places.googleapis.com/v1/places:searchText", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "X-Goog-Api-Key": env.GOOGLE_API_KEY,
        "X-Goog-FieldMask":
          "places.id,places.displayName,places.formattedAddress,places.nationalPhoneNumber," +
          "places.websiteUri,places.rating,places.userRatingCount,places.businessStatus,nextPageToken",
      },
      body: JSON.stringify(requete),
    });
    if (!r.ok) throw erreur("Google Places : " + r.status + " " + (await r.text()).slice(0, 200), 502);

    const data = await r.json();
    const lieux = (data.places || []).filter((p) => !p.businessStatus || p.businessStatus === "OPERATIONAL");
    const maintenant = maintenantSql();

    const requetes = lieux.map((p) => {
      const site = p.websiteUri || null;
      if (!site) sansSite++;
      return env.DB.prepare(UPSERT).bind(
        p.id,
        p.displayName?.text ?? "Sans nom",
        secteur,
        ville,
        p.formattedAddress ?? null,
        p.nationalPhoneNumber ?? null,
        p.rating ?? null,
        p.userRatingCount ?? null,
        site,
        site ? null : 100,
        site ? "" : "Aucun site web",
        site ? null : maintenant,
      );
    });
    if (requetes.length) await env.DB.batch(requetes);

    vus += lieux.length;
    jeton = data.nextPageToken;
    if (!jeton || !(data.places || []).length) break;
  }
  return { trouves: vus, sans_site: sansSite };
}

/* ---------- Analyse des sites existants ---------- */

const EN_ATTENTE = "site IS NOT NULL AND (analyse_le IS NULL OR analyse_le < datetime('now', '-30 days'))";

async function analyser(corps, env) {
  // Plan gratuit Workers : 50 sous-requêtes par exécution, donc de petits lots.
  const n = Math.min(Math.max(parseInt(corps.limit, 10) || 5, 1), 10);
  const { results } = await env.DB.prepare(
    "SELECT id, site FROM prospects WHERE " + EN_ATTENTE + " ORDER BY id LIMIT ?",
  ).bind(n).all();

  await Promise.all(
    results.map(async (ligne) => {
      const res = await analyseSite(ligne.site, env);
      await env.DB.prepare(
        "UPDATE prospects SET score = ?, raisons = ?, analyse_le = datetime('now') WHERE id = ?",
      ).bind(res.score, res.raisons.join(" | "), ligne.id).run();
    }),
  );

  const reste = await env.DB.prepare("SELECT COUNT(*) AS n FROM prospects WHERE " + EN_ATTENTE).first();
  return { analyses: results.length, restants: reste ? reste.n : 0 };
}

async function recupererPage(url) {
  try {
    const r = await fetch(url, {
      headers: { "User-Agent": UA, Accept: "text/html" },
      redirect: "follow",
      signal: AbortSignal.timeout(8000),
    });
    if (r.status >= 400 && ![401, 403, 429].includes(r.status)) return null;
    const type = r.headers.get("content-type") || "";
    const html = type.includes("text/html") ? (await r.text()).slice(0, 400000) : "";
    return { html, headers: r.headers, finalUrl: r.url };
  } catch {
    return null;
  }
}

async function pagespeed(url, env) {
  try {
    const r = await fetch(
      "https://www.googleapis.com/pagespeedonline/v5/runPagespeed?url=" + encodeURIComponent(url) +
        "&strategy=mobile&category=performance&key=" + env.GOOGLE_API_KEY,
      { signal: AbortSignal.timeout(45000) },
    );
    if (!r.ok) return null;
    const j = await r.json();
    const s = j?.lighthouseResult?.categories?.performance?.score;
    return s == null ? null : Math.round(s * 100);
  } catch {
    return null;
  }
}

async function wayback(hote) {
  try {
    const r = await fetch("https://archive.org/wayback/available?url=" + encodeURIComponent(hote), {
      signal: AbortSignal.timeout(8000),
    });
    const t = (await r.json())?.archived_snapshots?.closest?.timestamp;
    return t ? t.slice(0, 4) + "-" + t.slice(4, 6) + "-" + t.slice(6, 8) : null;
  } catch {
    return null;
  }
}

// Année la plus récente trouvée dans un © / copyright ou dans l'en-tête Last-Modified.
function derniereAnnee(html, lastModified) {
  const annees = [];
  const re = /(?:©|&copy;|&#169;|copyright)[^<]{0,60}?((?:19|20)\d{2})(?:\s*(?:-|–|—|&ndash;)\s*((?:19|20)\d{2}))?/gi;
  for (const m of html.matchAll(re)) {
    annees.push(Number(m[1]));
    if (m[2]) annees.push(Number(m[2]));
  }
  if (lastModified) {
    const d = new Date(lastModified);
    if (!isNaN(d)) annees.push(d.getUTCFullYear());
  }
  return annees.length ? Math.max(...annees) : null;
}

async function analyseSite(site, env) {
  const anneeCourante = new Date().getFullYear();
  let u;
  try {
    u = new URL(/^https?:\/\//i.test(site) ? site : "https://" + site);
  } catch {
    return { score: 90, raisons: ["Adresse du site invalide"] };
  }
  const hote = u.hostname.replace(/^www\./, "");
  if (SANS_SITE_PROPRE.some((d) => hote === d || hote.endsWith("." + d))) {
    return { score: 90, raisons: ["Pas de site propre (réseau social ou annuaire)"] };
  }

  const chemin = u.pathname + u.search;
  let https = true;
  let page = await recupererPage("https://" + u.host + chemin);
  if (!page) {
    https = false;
    page = await recupererPage("http://" + u.host + chemin);
  }
  if (!page) return { score: 90, raisons: ["Site injoignable"] };

  const [ps, snapshot] = await Promise.all([
    env.GOOGLE_API_KEY && env.USE_PAGESPEED !== "false" ? pagespeed(page.finalUrl || u.href, env) : null,
    wayback(hote),
  ]);

  let score = 0;
  const raisons = [];

  if (!https) {
    score += 20;
    raisons.push("Pas de HTTPS valide");
  }

  if (page.html) {
    if (!/<meta[^>]+name=["']viewport["']/i.test(page.html)) {
      score += 25;
      raisons.push("Non adapté au mobile (pas de balise viewport)");
    }
    const annee = derniereAnnee(page.html, page.headers.get("last-modified"));
    if (annee && annee <= anneeCourante - 3) {
      score += 20;
      raisons.push("Dernière mise à jour apparente en " + annee);
    }
    const obsolete =
      /<(marquee|blink|frameset|applet)\b/i.test(page.html) ||
      /\.swf\b/i.test(page.html) ||
      /jquery[-.\/]?(?:1|2)\.\d/i.test(page.html) ||
      (page.html.match(/<font\b/gi) || []).length > 5;
    if (obsolete) {
      score += 10;
      raisons.push("Technologies obsolètes (Flash, vieux jQuery, balises dépassées)");
    }
  } else {
    raisons.push("Contenu non analysable (protection anti-robot ou page non HTML)");
  }

  if (ps !== null && ps < 50) {
    score += 15;
    raisons.push("PageSpeed mobile faible (" + ps + "/100)");
  }

  if (score === 0 && page.html) raisons.unshift("Aucun point faible détecté");
  if (snapshot) raisons.push("Info : dernier snapshot archive.org le " + snapshot);

  return { score: Math.min(100, score), raisons };
}

/* ---------- Liste, statut, export ---------- */

async function interroger(url, env) {
  const min = parseInt(url.searchParams.get("min_score"), 10) || 0;
  const statut = url.searchParams.get("statut") || "";
  const q = (url.searchParams.get("q") || "").trim();

  let sql =
    "SELECT id, nom, secteur, ville, adresse, telephone, note, avis, site, score, raisons, analyse_le, statut, notes " +
    "FROM prospects WHERE COALESCE(score, -1) >= ?";
  const params = [min > 0 ? min : -1];
  if (STATUTS.includes(statut)) {
    sql += " AND statut = ?";
    params.push(statut);
  }
  if (q) {
    sql += " AND (nom LIKE ? OR ville LIKE ? OR secteur LIKE ? OR adresse LIKE ?)";
    const motif = "%" + q.replace(/[%_]/g, "") + "%";
    params.push(motif, motif, motif, motif);
  }
  sql += " ORDER BY COALESCE(score, -1) DESC, COALESCE(avis, 0) DESC LIMIT 1000";
  const { results } = await env.DB.prepare(sql).bind(...params).all();
  return results;
}

async function lister(url, env) {
  return interroger(url, env);
}

function celluleCsv(v) {
  let s = String(v ?? "");
  if (/^[=+\-@\t\r]/.test(s)) s = "'" + s; // neutralise les formules Excel
  return '"' + s.replace(/"/g, '""') + '"';
}

async function exporterCsv(url, env) {
  const lignes = await interroger(url, env);
  const colonnes = ["nom", "secteur", "ville", "adresse", "telephone", "note", "avis", "site", "score", "raisons", "statut", "notes"];
  // Séparateur « ; » et BOM pour une ouverture directe dans Excel en français.
  const csv =
    "\uFEFF" +
    [colonnes.join(";")]
      .concat(lignes.map((l) => colonnes.map((c) => celluleCsv(l[c])).join(";")))
      .join("\r\n");
  return new Response(csv, {
    headers: {
      "Content-Type": "text/csv; charset=utf-8",
      "Content-Disposition": 'attachment; filename="prospects.csv"',
      "Cache-Control": "no-store",
    },
  });
}

async function majStatut(corps, env) {
  const id = parseInt(corps.id, 10);
  if (!id) throw erreur("id requis");
  const statut = corps.statut ?? null;
  if (statut !== null && !STATUTS.includes(statut)) throw erreur("Statut inconnu");
  const notes = corps.notes === undefined ? null : String(corps.notes).slice(0, 2000);
  await env.DB.prepare("UPDATE prospects SET statut = COALESCE(?, statut), notes = COALESCE(?, notes) WHERE id = ?")
    .bind(statut, notes, id)
    .run();
  return { ok: true };
}

/* ---------- Page ---------- */

const PAGE = String.raw`<!doctype html>
<html lang="fr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Prospection web</title>
<style>
:root{--bg:#f5f6f8;--panel:#fff;--text:#1c2330;--muted:#5b6475;--line:#d8dce4;--accent:#1d4b73;--accent-soft:#e3edf6;--warn:#8a3b12;color-scheme:light}
*{box-sizing:border-box}
body{margin:0;background:var(--bg);color:var(--text);font:15px/1.5 ui-sans-serif,system-ui,-apple-system,"Segoe UI",Roboto,Helvetica,Arial,sans-serif}
main{max-width:1100px;margin:0 auto;padding:20px 16px 48px}
h1{font-size:1.4rem;margin:0 0 4px}
.sub{color:var(--muted);margin:0 0 20px}
.panel{background:var(--panel);border:1px solid var(--line);border-radius:6px;padding:14px;margin-bottom:14px}
.row{display:flex;flex-wrap:wrap;gap:10px;align-items:end}
label{display:flex;flex-direction:column;gap:4px;font-size:.85rem;color:var(--muted)}
input,select,button{font:inherit;padding:8px 10px;border:1px solid var(--line);border-radius:4px;background:#fff;color:var(--text)}
button,a.btn{background:var(--accent);border:1px solid var(--accent);color:#fff;cursor:pointer;font:inherit;padding:8px 12px;border-radius:4px;text-decoration:none}
button.secondary,a.btn.secondary{background:#fff;color:var(--accent)}
button:disabled{opacity:.55;cursor:wait}
:focus-visible{outline:2px solid var(--accent);outline-offset:2px}
#msg{margin:10px 0 0;min-height:1.4em;color:var(--muted)}
#msg.err{color:var(--warn)}
.table-wrap{overflow-x:auto;border:1px solid var(--line);border-radius:6px}
table{width:100%;border-collapse:collapse;background:var(--panel)}
th,td{text-align:left;vertical-align:top;padding:10px;border-bottom:1px solid var(--line)}
th{font-size:.82rem;color:var(--muted);font-weight:600;background:#fafbfc}
tr:last-child td{border-bottom:0}
.score{display:inline-block;min-width:2.6em;text-align:center;padding:2px 8px;border-radius:999px;font-weight:600;background:#eceff3;color:var(--muted)}
.score.hi{background:var(--accent);color:#fff}
.score.mid{background:var(--accent-soft);color:var(--accent)}
.small{color:var(--muted);font-size:.85rem}
td input[type=text]{width:100%;min-width:140px}
a{color:var(--accent)}
.vide{padding:24px;text-align:center;color:var(--muted)}
@media (max-width:720px){
  thead{display:none}
  table,tbody,tr,td{display:block;width:100%}
  tr{border-bottom:8px solid var(--bg);padding:6px 0}
  td{border:0;padding:4px 12px}
  td[data-l]::before{content:attr(data-l) " : ";color:var(--muted);font-size:.82rem}
}
</style>
</head>
<body>
<main>
  <h1>Prospection web</h1>
  <p class="sub">Repérez les commerces locaux sans site ou avec un site ancien.</p>

  <section class="panel" aria-label="Nouvelle recherche">
    <div class="row">
      <label>Secteur<input id="secteur" placeholder="ex. coiffeur"></label>
      <label>Ville<input id="ville" placeholder="ex. La Baule"></label>
      <label>Résultats
        <select id="max"><option>20</option><option>40</option><option>60</option></select>
      </label>
      <button id="go">Rechercher</button>
      <button id="an" class="secondary">Analyser les sites</button>
    </div>
    <p id="msg" role="status"></p>
  </section>

  <section class="panel" aria-label="Filtres">
    <div class="row">
      <label>Recherche<input id="q" placeholder="nom, ville, secteur"></label>
      <label>Score minimum
        <select id="min"><option value="0">Tous</option><option value="30">30</option><option value="50">50</option><option value="70">70</option><option value="90">90</option></select>
      </label>
      <label>Statut<select id="st"><option value="">Tous</option></select></label>
      <a id="csv" class="btn secondary" href="/api/export.csv">Exporter en CSV</a>
    </div>
  </section>

  <div class="table-wrap">
    <table>
      <thead><tr><th>Score</th><th>Établissement</th><th>Téléphone</th><th>Site</th><th>Points faibles</th><th>Statut</th><th>Notes</th></tr></thead>
      <tbody id="rows"></tbody>
    </table>
  </div>
</main>
<script>
const $ = (s) => document.querySelector(s);
const STATUTS = ["à contacter", "contacté", "relancé", "refus", "client"];

function esc(s) {
  return String(s == null ? "" : s).replace(/[&<>"']/g, (c) => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
}
function msg(t, err) { const m = $("#msg"); m.textContent = t; m.className = err ? "err" : ""; }

async function api(path, body) {
  const opts = body ? { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) } : undefined;
  const r = await fetch(path, opts);
  const j = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(j.error || ("Erreur " + r.status));
  return j;
}

function ligne(p) {
  const cls = p.score == null ? "" : p.score >= 80 ? "hi" : p.score >= 50 ? "mid" : "";
  const score = p.score == null ? "—" : p.score;
  const site = p.site && /^https?:\/\//.test(p.site)
    ? '<a href="' + esc(p.site) + '" target="_blank" rel="noopener noreferrer">' + esc(p.site.replace(/^https?:\/\/(www\.)?/, "").slice(0, 40)) + '</a>'
    : '<span class="small">Aucun</span>';
  const raisons = p.analyse_le || p.score != null
    ? esc(p.raisons || "").split(" | ").join("<br>")
    : '<span class="small">En attente d\'analyse</span>';
  const options = STATUTS.map((s) => '<option' + (s === p.statut ? " selected" : "") + '>' + esc(s) + '</option>').join("");
  const note = p.note != null ? " · " + esc(p.note) + "/5 (" + esc(p.avis || 0) + " avis)" : "";
  return '<tr>' +
    '<td><span class="score ' + cls + '">' + score + '</span></td>' +
    '<td><strong>' + esc(p.nom) + '</strong><div class="small">' + esc(p.secteur) + note + '<br>' + esc(p.adresse || "") + '</div></td>' +
    '<td data-l="Téléphone">' + esc(p.telephone || "—") + '</td>' +
    '<td data-l="Site">' + site + '</td>' +
    '<td data-l="Points faibles">' + raisons + '</td>' +
    '<td data-l="Statut"><select data-id="' + p.id + '" data-k="statut" aria-label="Statut">' + options + '</select></td>' +
    '<td data-l="Notes"><input type="text" data-id="' + p.id + '" data-k="notes" value="' + esc(p.notes || "") + '" aria-label="Notes"></td>' +
    '</tr>';
}

async function charger() {
  const p = new URLSearchParams({ q: $("#q").value, min_score: $("#min").value, statut: $("#st").value });
  const j = await api("/api/prospects?" + p);
  $("#rows").innerHTML = j.prospects.length
    ? j.prospects.map(ligne).join("")
    : '<tr><td colspan="7" class="vide">Aucun résultat. Lancez une recherche ci-dessus.</td></tr>';
  $("#csv").href = "/api/export.csv?" + p;
}

$("#st").innerHTML = '<option value="">Tous</option>' + STATUTS.map((s) => '<option>' + esc(s) + '</option>').join("");

$("#go").onclick = async () => {
  const b = $("#go"); b.disabled = true; msg("Recherche en cours…");
  try {
    const j = await api("/api/search", { secteur: $("#secteur").value, ville: $("#ville").value, max: Number($("#max").value) });
    msg(j.trouves + " établissements trouvés, dont " + j.sans_site + " sans site. Lancez l'analyse pour évaluer les autres.");
    await charger();
  } catch (e) { msg(e.message, true); } finally { b.disabled = false; }
};

$("#an").onclick = async () => {
  const b = $("#an"); b.disabled = true; let faits = 0;
  try {
    for (let i = 0; i < 60; i++) {
      const j = await api("/api/analyze", { limit: 8 });
      faits += j.analyses;
      msg(faits + " site(s) analysé(s), " + j.restants + " restant(s)…");
      if (!j.restants || !j.analyses) break;
    }
    msg("Analyse terminée : " + faits + " site(s) analysé(s).");
    await charger();
  } catch (e) { msg(e.message, true); } finally { b.disabled = false; }
};

$("#rows").addEventListener("change", async (ev) => {
  const el = ev.target;
  if (!el.dataset || !el.dataset.id) return;
  const corps = { id: Number(el.dataset.id) };
  corps[el.dataset.k] = el.value;
  try { await api("/api/status", corps); msg("Enregistré."); } catch (e) { msg(e.message, true); }
});

["q", "min", "st"].forEach((id) => $("#" + id).addEventListener("input", () => charger().catch((e) => msg(e.message, true))));
charger().catch((e) => msg(e.message, true));
</script>
</body>
</html>`;
