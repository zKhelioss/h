CREATE TABLE IF NOT EXISTS prospects (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  place_id TEXT UNIQUE NOT NULL,
  nom TEXT NOT NULL,
  secteur TEXT,
  ville TEXT,
  adresse TEXT,
  telephone TEXT,
  note REAL,
  avis INTEGER,
  site TEXT,
  score INTEGER,
  raisons TEXT NOT NULL DEFAULT '',
  analyse_le TEXT,
  statut TEXT NOT NULL DEFAULT 'à contacter',
  notes TEXT NOT NULL DEFAULT '',
  cree_le TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_prospects_score ON prospects (score);
CREATE INDEX IF NOT EXISTS idx_prospects_statut ON prospects (statut);
